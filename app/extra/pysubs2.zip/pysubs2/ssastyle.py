import warnings
from typing import Dict,Any,ClassVar,FrozenSet
import dataclasses
from.common import Color,Alignment
@dataclasses.dataclass(repr=False)
class SSAStyle:
	DEFAULT_STYLE:ClassVar['SSAStyle']=None
	@property
	def FIELDS(self)->FrozenSet[str]:warnings.warn("Deprecated in 1.2.0 - it's a dataclass now",DeprecationWarning);return frozenset(field.name for field in dataclasses.fields(self))
	fontname:str='Arial';fontsize:float=2e1;primarycolor:Color=dataclasses.field(default_factory=lambda:Color(255,255,255,0));secondarycolor:Color=dataclasses.field(default_factory=lambda:Color(255,0,0,0));tertiarycolor:Color=dataclasses.field(default_factory=lambda:Color(0,0,0,0));outlinecolor:Color=dataclasses.field(default_factory=lambda:Color(0,0,0,0));backcolor:Color=dataclasses.field(default_factory=lambda:Color(0,0,0,0));bold:bool=False;italic:bool=False;underline:bool=False;strikeout:bool=False;scalex:float=1e2;scaley:float=1e2;spacing:float=.0;angle:float=.0;borderstyle:int=1;outline:float=2.;shadow:float=2.;alignment:Alignment=Alignment.BOTTOM_CENTER;marginl:int=10;marginr:int=10;marginv:int=10;alphalevel:int=0;encoding:int=1;drawing:bool=False
	def copy(self)->'SSAStyle':return SSAStyle(**self.as_dict())
	def as_dict(self)->Dict[str,Any]:return{field.name:getattr(self,field.name)for field in dataclasses.fields(self)}
	def __repr__(self)->str:return f"<SSAStyle {self.fontsize!r}px{" bold"if self.bold else""}{" italic"if self.italic else""} {self.fontname!r}>"
SSAStyle.DEFAULT_STYLE=SSAStyle()
