import io
from itertools import chain
import os.path,logging
from typing import Optional,List,Dict,Iterable,Any,overload,Iterator,TextIO,Tuple,MutableSequence
from.common import IntOrFloat
from.ssaevent import SSAEvent
from.ssastyle import SSAStyle
from.time import make_time,ms_to_str
class SSAFile(MutableSequence[SSAEvent]):
	DEFAULT_INFO:Dict[str,str]={'WrapStyle':'0','ScaledBorderAndShadow':'yes','Collisions':'Normal'}
	def __init__(self)->None:(self.events):List[SSAEvent]=[];(self.styles):Dict[str,SSAStyle]={'Default':SSAStyle.DEFAULT_STYLE.copy()};(self.info):Dict[str,str]=self.DEFAULT_INFO.copy();(self.aegisub_project):Dict[str,str]={};(self.fonts_opaque):Dict[str,Any]={};(self.graphics_opaque):Dict[str,Any]={};(self.fps):Optional[float]=None;(self.format):Optional[str]=None
	@classmethod
	def load(cls,path:str,encoding:str='utf-8',format_:Optional[str]=None,fps:Optional[float]=None,errors:Optional[str]=None,**kwargs:Any)->'SSAFile':
		with open(path,encoding=encoding,errors=errors)as fp:return cls.from_file(fp,format_,fps=fps,**kwargs)
	@classmethod
	def from_string(cls,string:str,format_:Optional[str]=None,fps:Optional[float]=None,**kwargs:Any)->'SSAFile':fp=io.StringIO(string);return cls.from_file(fp,format_,fps=fps,**kwargs)
	@classmethod
	def from_file(cls,fp:TextIO,format_:Optional[str]=None,fps:Optional[float]=None,**kwargs:Any)->'SSAFile':
		if format_ is None:text=fp.read();fragment=text[:10000];format_=autodetect_format(fragment);fp=io.StringIO(text)
		impl=get_format_class(format_);subs=cls();subs.format=format_;subs.fps=fps;impl.from_file(subs,fp,format_,fps=fps,**kwargs);return subs
	def save(self,path:str,encoding:str='utf-8',format_:Optional[str]=None,fps:Optional[float]=None,errors:Optional[str]=None,**kwargs:Any)->None:
		if format_ is None:ext=os.path.splitext(path)[1].lower();format_=get_format_identifier(ext)
		with open(path,'w',encoding=encoding,errors=errors)as fp:self.to_file(fp,format_,fps=fps,**kwargs)
	def to_string(self,format_:str,fps:Optional[float]=None,**kwargs:Any)->str:fp=io.StringIO();self.to_file(fp,format_,fps=fps,**kwargs);return fp.getvalue()
	def to_file(self,fp:TextIO,format_:str,fps:Optional[float]=None,**kwargs:Any)->None:impl=get_format_class(format_);impl.to_file(self,fp,format_,fps=fps,**kwargs)
	def shift(self,h:IntOrFloat=0,m:IntOrFloat=0,s:IntOrFloat=0,ms:IntOrFloat=0,frames:Optional[int]=None,fps:Optional[float]=None)->None:
		delta=make_time(h=h,m=m,s=s,ms=ms,frames=frames,fps=fps)
		for line in self:line.start+=delta;line.end+=delta
	def transform_framerate(self,in_fps:float,out_fps:float)->None:
		if in_fps<=0 or out_fps<=0:raise ValueError(f"Framerates must be positive, cannot transform {in_fps} -> {out_fps}")
		ratio=in_fps/out_fps
		for line in self:line.start=int(round(line.start*ratio));line.end=int(round(line.end*ratio))
	def rename_style(self,old_name:str,new_name:str)->None:
		from.formats.substation import is_valid_field_content
		if old_name not in self.styles:raise KeyError(f"Style {old_name!r} not found")
		if new_name in self.styles:raise ValueError(f"There is already a style called {new_name!r}")
		if not is_valid_field_content(new_name):raise ValueError(f"{new_name!r} is not a valid name")
		self.styles[new_name]=self.styles[old_name];del self.styles[old_name]
		for line in self:
			if line.style==old_name:line.style=new_name
	def import_styles(self,subs:'SSAFile',overwrite:bool=True)->None:
		if not isinstance(subs,SSAFile):raise TypeError('Must supply an SSAFile.')
		for(name,style)in subs.styles.items():
			if name not in self.styles or overwrite:self.styles[name]=style
	def remove_miscellaneous_events(self)->None:
		new_events=[];duplicate_text_ids=set();times_to_texts:Dict[Tuple[int,int],List[str]]={}
		for(i,e)in enumerate(self):
			tmp=times_to_texts.setdefault((e.start,e.end),[])
			if tmp.count(e.plaintext)>0:duplicate_text_ids.add(i)
			tmp.append(e.plaintext)
		for(i,e)in enumerate(self):
			if e.is_drawing or e.is_comment:continue
			if len(e.plaintext.strip())<2:continue
			if i in duplicate_text_ids:continue
			new_events.append(e)
		self.events=new_events
	def get_text_events(self)->List[SSAEvent]:return[e for e in self if e.is_text]
	def equals(self,other:'SSAFile')->bool:
		if isinstance(other,SSAFile):
			for key in set(chain(self.info.keys(),other.info.keys()))-{'ScriptType'}:
				self_info,other_info=self.info.get(key),other.info.get(key)
				if self_info is None:logging.debug('%r missing in self.info',key);return False
				elif other_info is None:logging.debug('%r missing in other.info',key);return False
				elif self_info!=other_info:logging.debug('info %r differs (self=%r, other=%r)',key,self_info,other_info);return False
			for key in set(chain(self.fonts_opaque.keys(),other.fonts_opaque.keys())):
				self_font,other_font=self.fonts_opaque.get(key),other.fonts_opaque.get(key)
				if self_font is None:logging.debug('%r missing in self.fonts_opaque',key);return False
				elif other_font is None:logging.debug('%r missing in other.fonts_opaque',key);return False
				elif self_font!=other_font:logging.debug('fonts_opaque %r differs (self=%r, other=%r)',key,self_font,other_font);return False
			for key in set(chain(self.graphics_opaque.keys(),other.graphics_opaque.keys())):
				self_image,other_image=self.graphics_opaque.get(key),other.graphics_opaque.get(key)
				if self_image is None:logging.debug('%r missing in self.graphics_opaque',key);return False
				elif other_image is None:logging.debug('%r missing in other.graphics_opaque',key);return False
				elif self_image!=other_image:logging.debug('graphics_opaque %r differs (self=%r, other=%r)',key,self_image,other_image);return False
			for key in set(chain(self.styles.keys(),other.styles.keys())):
				self_style,other_style=self.styles.get(key),other.styles.get(key)
				if self_style is None:logging.debug('%r missing in self.styles',key);return False
				elif other_style is None:logging.debug('%r missing in other.styles',key);return False
				elif self_style!=other_style:
					for k in self_style.FIELDS:
						if getattr(self_style,k)!=getattr(other_style,k):logging.debug('difference in field %r',k)
					logging.debug('style %r differs (self=%r, other=%r)',key,self_style.as_dict(),other_style.as_dict());return False
			if len(self)!=len(other):logging.debug('different # of subtitles (self=%d, other=%d)',len(self),len(other));return False
			for(i,(self_event,other_event))in enumerate(zip(self.events,other.events)):
				if not self_event.equals(other_event):
					for k in self_event.FIELDS:
						if getattr(self_event,k)!=getattr(other_event,k):logging.debug('difference in field %r',k)
					logging.debug('event %d differs (self=%r, other=%r)',i,self_event.as_dict(),other_event.as_dict());return False
			return True
		else:raise TypeError('Cannot compare to non-SSAFile object')
	def __repr__(self)->str:
		if self.events:max_time=max(ev.end for ev in self);s=f"<SSAFile with {len(self)} events and {len(self.styles)} styles, last timestamp {ms_to_str(max_time)}>"
		else:s=f"<SSAFile with 0 events and {len(self.styles)} styles>"
		return s
	def sort(self)->None:self.events.sort()
	def __iter__(self)->Iterator[SSAEvent]:return iter(self.events)
	@overload
	def __getitem__(self,item:int)->SSAEvent:pass
	@overload
	def __getitem__(self,s:slice)->List[SSAEvent]:pass
	def __getitem__(self,item:Any)->Any:return self.events[item]
	@overload
	def __setitem__(self,key:int,value:SSAEvent)->None:pass
	@overload
	def __setitem__(self,keys:slice,values:Iterable[SSAEvent])->None:pass
	def __setitem__(self,key:Any,value:Any)->None:
		if isinstance(key,int):
			if isinstance(value,SSAEvent):self.events[key]=value
			else:raise TypeError('SSAFile.events must contain only SSAEvent objects')
		elif isinstance(key,slice):
			values=list(value)
			if all(isinstance(v,SSAEvent)for v in values):self.events[key]=values
			else:raise TypeError('SSAFile.events must contain only SSAEvent objects')
		else:raise TypeError('Bad key type')
	@overload
	def __delitem__(self,key:int)->None:pass
	@overload
	def __delitem__(self,s:slice)->None:pass
	def __delitem__(self,key:Any)->None:del self.events[key]
	def __len__(self)->int:return len(self.events)
	def insert(self,index:int,value:SSAEvent)->None:
		if isinstance(value,SSAEvent):self.events.insert(index,value)
		else:raise TypeError('SSAFile.events must contain only SSAEvent objects')
from.formats import autodetect_format,get_format_class,get_format_identifier
