from typing import List,Any
__all__=['Pysubs2Error','UnknownFPSError','UnknownFileExtensionError','UnknownFormatIdentifierError','FormatAutodetectionError']
class Pysubs2Error(Exception):0
class UnknownFPSError(Pysubs2Error):0
class UnknownFileExtensionError(Pysubs2Error):
	def __init__(self,ext:str)->None:self.ext=ext;msg=f"File extension {ext!r} does not match any supported subtitle format";super().__init__(msg)
	def __reduce__(self)->Any:return self.__class__,(self.ext,)
class UnknownFormatIdentifierError(Pysubs2Error):
	def __init__(self,format_:str)->None:self.format_=format_;msg=f"Format identifier {format_!r} does not match any supported subtitle format";super().__init__(msg)
	def __reduce__(self)->Any:return self.__class__,(self.format_,)
class FormatAutodetectionError(Pysubs2Error):
	def __init__(self,content:str,formats:List[str])->None:
		self.content=content;self.formats=formats
		if not formats:msg='No suitable formats'
		else:msg=f"Multiple suitable formats ({formats!r})"
		super().__init__(msg)
	def __reduce__(self)->Any:return self.__class__,(self.content,self.formats)
