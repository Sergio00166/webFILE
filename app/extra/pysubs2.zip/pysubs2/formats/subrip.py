import re,warnings
from typing import List,Sequence,Optional,TextIO,Any,Tuple
from.base import FormatBase
from..ssaevent import SSAEvent
from..ssastyle import SSAStyle
from.substation import parse_tags
from..time import ms_to_times,make_time,TIMESTAMP,timestamp_to_ms
from..ssafile import SSAFile
MAX_REPRESENTABLE_TIME=make_time(h=100)-1
class SubripFormat(FormatBase):
	TIMESTAMP=TIMESTAMP
	@staticmethod
	def ms_to_timestamp(ms:int)->str:
		if ms<0:ms=0
		if ms>MAX_REPRESENTABLE_TIME:warnings.warn('Overflow in SubRip timestamp, clamping to MAX_REPRESENTABLE_TIME',RuntimeWarning);ms=MAX_REPRESENTABLE_TIME
		h,m,s,ms=ms_to_times(ms);return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
	@staticmethod
	def timestamp_to_ms(groups:Sequence[str])->int:return timestamp_to_ms(groups)
	@classmethod
	def guess_format(cls,text:str)->Optional[str]:
		if'[Script Info]'in text or'[V4+ Styles]'in text:return None
		if text.lstrip().startswith('WEBVTT'):return None
		if'http://www.w3.org/ns/ttml'in text:return None
		for line in text.splitlines():
			if len(cls.TIMESTAMP.findall(line))==2:return'srt'
		return None
	@classmethod
	def from_file(cls,subs:'SSAFile',fp:TextIO,format_:str,keep_html_tags:bool=False,keep_unknown_html_tags:bool=False,**kwargs:Any)->None:
		timestamps:List[Tuple[int,int]]=[];following_lines:List[List[str]]=[]
		for line in fp:
			stamps=cls.TIMESTAMP.findall(line)
			if len(stamps)==2:start,end=map(cls.timestamp_to_ms,stamps);timestamps.append((start,end));following_lines.append([])
			elif timestamps:following_lines[-1].append(line)
		def prepare_text(lines:List[str])->str:
			if len(lines)>=2 and all(re.match('\\s*$',line)for line in lines[:-1])and re.match('\\s*\\d+\\s*$',lines[-1]):return''
			s=''.join(lines).strip();s=re.sub('\\n+ *\\d+ *$','',s)
			if not keep_html_tags:s=re.sub('< *i *>','{\\\\i1}',s);s=re.sub('< */ *i *>','{\\\\i0}',s);s=re.sub('< *s *>','{\\\\s1}',s);s=re.sub('< */ *s *>','{\\\\s0}',s);s=re.sub('< *u *>','{\\\\u1}',s);s=re.sub('< */ *u *>','{\\\\u0}',s);s=re.sub('< *b *>','{\\\\b1}',s);s=re.sub('< */ *b *>','{\\\\b0}',s)
			if not(keep_html_tags or keep_unknown_html_tags):s=re.sub('< */? *[a-zA-Z][^>]*>','',s)
			s=re.sub('\\n','\\\\N',s);return s
		for((start,end),lines)in zip(timestamps,following_lines):e=SSAEvent(start=start,end=end,text=prepare_text(lines));subs.append(e)
	@classmethod
	def to_file(cls,subs:'SSAFile',fp:TextIO,format_:str,apply_styles:bool=True,keep_ssa_tags:bool=False,**kwargs:Any)->None:
		def prepare_text(text:str,style:SSAStyle)->str:
			text=text.replace('\\h',' ');text=text.replace('\\n','\n');text=text.replace('\\N','\n');body=[]
			if keep_ssa_tags:body.append(text)
			else:
				for(fragment,sty)in parse_tags(text,style,subs.styles):
					if apply_styles:
						if sty.italic:fragment=f"<i>{fragment}</i>"
						if sty.underline:fragment=f"<u>{fragment}</u>"
						if sty.strikeout:fragment=f"<s>{fragment}</s>"
					body.append(fragment)
			return re.sub('\n+','\n',''.join(body).strip())
		for(lineno,line)in enumerate(cls._get_visible_lines(subs),1):start=cls.ms_to_timestamp(line.start);end=cls.ms_to_timestamp(line.end);text=prepare_text(line.text,subs.styles.get(line.style,SSAStyle.DEFAULT_STYLE));print(lineno,file=fp);print(start,'-->',end,file=fp);print(text,end='\n\n',file=fp);lineno+=1
	@classmethod
	def _get_visible_lines(cls,subs:'SSAFile')->List[SSAEvent]:return subs.get_text_events()
