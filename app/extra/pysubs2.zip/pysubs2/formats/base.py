from typing import Optional,Any,TextIO
from..ssafile import SSAFile
class FormatBase:
	@classmethod
	def from_file(cls,subs:'SSAFile',fp:TextIO,format_:str,**kwargs:Any)->None:raise NotImplementedError('Parsing is not supported for this format')
	@classmethod
	def to_file(cls,subs:'SSAFile',fp:TextIO,format_:str,**kwargs:Any)->None:raise NotImplementedError('Writing is not supported for this format')
	@classmethod
	def guess_format(cls,text:str)->Optional[str]:return None
