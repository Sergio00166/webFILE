import re
from typing import Optional,Sequence,NamedTuple
from.common import IntOrFloat
TIMESTAMP=re.compile('(\\d{1,2}):(\\d{1,2}):(\\d{1,2})[.,](\\d{1,3})')
TIMESTAMP_SHORT=re.compile('(\\d{1,2}):(\\d{2}):(\\d{2})')
class Times(NamedTuple):h:int;m:int;s:int;ms:int
def make_time(h:IntOrFloat=0,m:IntOrFloat=0,s:IntOrFloat=0,ms:IntOrFloat=0,frames:Optional[int]=None,fps:Optional[float]=None)->int:
	if frames is None and fps is None:return times_to_ms(h,m,s,ms)
	elif frames is not None and fps is not None:return frames_to_ms(frames,fps)
	else:raise ValueError('Both fps and frames must be specified')
def timestamp_to_ms(groups:Sequence[str])->int:
	h:int;m:int;s:int;ms:int;frac:int
	if len(groups)==4:h,m,s,frac=map(int,groups);ms=frac*10**(3-len(groups[-1]))
	elif len(groups)==3:h,m,s=map(int,groups);ms=0
	else:raise ValueError('Unexpected number of groups')
	ms+=s*1000;ms+=m*60000;ms+=h*3600000;return ms
def times_to_ms(h:IntOrFloat=0,m:IntOrFloat=0,s:IntOrFloat=0,ms:IntOrFloat=0)->int:ms+=s*1000;ms+=m*60000;ms+=h*3600000;return int(round(ms))
def frames_to_ms(frames:int,fps:float)->int:
	if fps<=0:raise ValueError(f"Framerate must be a positive number ({fps}).")
	return int(round(frames*(1000/fps)))
def ms_to_frames(ms:IntOrFloat,fps:float)->int:
	if fps<=0:raise ValueError(f"Framerate must be a positive number ({fps}).")
	return int(round(ms/1000*fps))
def ms_to_times(ms:IntOrFloat)->Times:ms=int(round(ms));h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000);return Times(h,m,s,ms)
def ms_to_str(ms:IntOrFloat,fractions:bool=False)->str:
	sgn='-'if ms<0 else'';h,m,s,ms=ms_to_times(abs(ms))
	if fractions:return f"{sgn}{h:01d}:{m:02d}:{s:02d}.{ms:03d}"
	else:return f"{sgn}{h:01d}:{m:02d}:{s:02d}"
