import re,warnings
from typing import Optional,Dict,Any,ClassVar,FrozenSet
import dataclasses
from.common import IntOrFloat
from.time import ms_to_str,make_time
@dataclasses.dataclass(repr=False,eq=False,order=False)
class SSAEvent:
	OVERRIDE_SEQUENCE:ClassVar=re.compile('{[^}]*}');start:int=0;end:int=10000;text:str='';marked:bool=False;layer:int=0;style:str='Default';name:str='';marginl:int=0;marginr:int=0;marginv:int=0;effect:str='';type:str='Dialogue'
	@property
	def FIELDS(self)->FrozenSet[str]:warnings.warn("Deprecated in 1.2.0 - it's a dataclass now",DeprecationWarning);return frozenset(field.name for field in dataclasses.fields(self))
	@property
	def duration(self)->IntOrFloat:return self.end-self.start
	@duration.setter
	def duration(self,ms:int)->None:
		if ms>=0:self.end=self.start+ms
		else:raise ValueError('Subtitle duration cannot be negative')
	@property
	def is_comment(self)->bool:return self.type=='Comment'
	@is_comment.setter
	def is_comment(self,value:bool)->None:
		if value:self.type='Comment'
		else:self.type='Dialogue'
	@property
	def is_drawing(self)->bool:from.formats.substation import parse_tags;return any(sty.drawing for(_,sty)in parse_tags(self.text))
	@property
	def is_text(self)->bool:return not(self.is_comment or self.is_drawing)
	@property
	def plaintext(self)->str:text=self.text;text=self.OVERRIDE_SEQUENCE.sub('',text);text=text.replace('\\h',' ');text=text.replace('\\n','\n');text=text.replace('\\N','\n');return text
	@plaintext.setter
	def plaintext(self,text:str)->None:self.text=text.replace('\n','\\N')
	def shift(self,h:IntOrFloat=0,m:IntOrFloat=0,s:IntOrFloat=0,ms:IntOrFloat=0,frames:Optional[int]=None,fps:Optional[float]=None)->None:delta=make_time(h=h,m=m,s=s,ms=ms,frames=frames,fps=fps);self.start+=delta;self.end+=delta
	def copy(self)->'SSAEvent':return SSAEvent(**self.as_dict())
	def as_dict(self)->Dict[str,Any]:return{field.name:getattr(self,field.name)for field in dataclasses.fields(self)}
	def equals(self,other:'SSAEvent')->bool:
		if isinstance(other,SSAEvent):return self.as_dict()==other.as_dict()
		else:raise TypeError('Cannot compare to non-SSAEvent object')
	def __eq__(self,other:object)->bool:
		if not isinstance(other,SSAEvent):return NotImplemented
		return self.start==other.start and self.end==other.end
	def __ne__(self,other:object)->bool:
		if not isinstance(other,SSAEvent):return NotImplemented
		return self.start!=other.start or self.end!=other.end
	def __lt__(self,other:object)->bool:
		if not isinstance(other,SSAEvent):return NotImplemented
		return(self.start,self.end)<(other.start,other.end)
	def __le__(self,other:object)->bool:
		if not isinstance(other,SSAEvent):return NotImplemented
		return(self.start,self.end)<=(other.start,other.end)
	def __gt__(self,other:object)->bool:
		if not isinstance(other,SSAEvent):return NotImplemented
		return(self.start,self.end)>(other.start,other.end)
	def __ge__(self,other:object)->bool:
		if not isinstance(other,SSAEvent):return NotImplemented
		return(self.start,self.end)>=(other.start,other.end)
	def __repr__(self)->str:return f"<SSAEvent type={self.type} start={ms_to_str(self.start)} end={ms_to_str(self.end)} text={self.text!r}>"
